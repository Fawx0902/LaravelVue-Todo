<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use ReallySimpleJWT\Token;

class VerifyUserToken
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
       if ($request->header('Authorization')) {
            $authorizationHeader = $request->header('Authorization');
            $token = explode(' ', $authorizationHeader);
            $secret = env('ACCESS_TOKEN');

            $result = Token::validate($token[1], $secret);
            if(!$result){
                return response()->json(['message' => 'Invalid Authorization Token.'], 401)
               ->header('Content-Type','application/json');
            }

            $checkToken = Token::validateExpiration($token[1], $secret);
            if(!$checkToken){
                return response()->json(['message' => 'Login Expired.'], 401)
               ->header('Content-Type','application/json');
            }

            return $next($request);
       } else {
            return response()->json(['message' => 'Missing Authorization Header.'], 401)
            ->header('Content-Type','application/json');
       }
    }
}
