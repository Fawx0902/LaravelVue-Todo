<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\UserDetail;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

use ReallySimpleJWT\Token;

use Exception;

class UserController extends Controller
{
    public function loginUser(Request $request) {
        try {
            $request->merge([
                'username' => strtolower($request->input('username'))
            ]);

            $validator = Validator::make($request->all(), [
                'username' => 'required',
                'password' => 'required',
            ]);
        
            if ($validator->fails()) {
                return response()->json([
                    'message' => $validator->errors()->first(),
                    'status' => 'Unprocessable Entity!',
                ], 422);
            }

            if (!Auth::attempt($request->only('username', 'password'))) {
                $user = User::where('username', $request->input('username'))->first();

                if (!$user){
                    return response()->json([
                        'message' => 'Details do not exist in the database.',
                        'status' => 'error',
                    ], 401);
                } else {
                    return response()->json([
                        'message' => 'Incorrect Credentials.',
                        'status' => 'error',
                    ], 401);
                }
                
            } else {
                $expiryTime = $request->rememberMe ? time() + (10 * 365 * 24 * 60 * 60) : time() + 28800; // 10 years | 8 hours

                $token = Token::create(
                    Auth::User()->id,
                    env('ACCESS_TOKEN'),
                    $expiryTime,
                    'localhost'
                );

                return response()->json([
                    'message' => 'User Login!',
                    'accessToken' => $token,
                    'status' => 'success',
                ], 200)
                    ->header('Content-Type', 'application/json')
                    ->header('Authorization', 'Bearer '.$token);
            }
        } catch (Exception $e) {
            return response((array)[
                'data' => $e->getMessage(),
                'file' => $e->getFile(),
                'line_error' => $e->getLine(),
                'message' => "There is an error occured.",
                'status' => 'error'
            ], 500);
        }
    }

    public function userProfile(Request $request) {
        $basic = $request->header('Authorization');
        $split = explode(' ', $basic);
        $user = $this->getPayload($split[1]);

        if(!$user)
            return response()->json([
                'message' => 'Unauthorized',
                'status' => 'error',
            ], 401);

        $data = User::where([['id', '=', $user['user_id']]])->with('userDetail')->first();

        return response()->json([
            'data' => $data,
            'status' => 'success',
        ], 200);
    }

    public function GetUserTable(Request $request) {
        $basic = $request->header('Authorization');
        $split = explode(' ', $basic);
        $user = $this->getPayload($split[1]);

        if(!$user || $user['user_type'] !== 'Admin')
            return response()->json([
                'message' => 'Unauthorized',
                'status' => 'error',
            ], 401);
        
        try {
            $input = $request->only('page', 'limit', 'search', 'tabStatus', 'selectedUserType');
            $query = User::with(['userDetail' => function ($query) {
                    $query->withTrashed();
                }])
                ->when($input['tabStatus'] === "Archived", function ($query){
                    $query->onlyTrashed();
                })
                ->when($input['tabStatus'] === "All", function ($query){
                    $query->withTrashed();
                })
                ->when($input['selectedUserType'] !== "All", function ($query) use ($input){
                    $query->where('user_type', $input['selectedUserType']);
                })
                ->orderBy('updated_at', 'desc')
                ->select('*');

            if ($request->filled('search') && strlen($input['search']) >= 2) {
                $search_term = $input['search'];
                $query->where(function ($query) use ($search_term) {
                    $query->where('username', 'LIKE', '%' . $search_term . '%')
                        ->orWhereHas('userDetail', function ($query) use ($search_term) {
                            $query->where('first_name', 'LIKE', '%' . $search_term . '%')
                                ->orWhere('last_name', 'LIKE', '%' . $search_term . '%')
                                ->orWhere('email', 'LIKE', '%' . $search_term . '%');
                        });
                });
            }

            // Count totals based on the filtered query
            $totalOverall = $query->count();
            $totalActive = (clone $query)->withoutTrashed()->count();
            $totalArchive = (clone $query)->onlyTrashed()->count();
            
            $userData = $query->skip($input['page'] * $input['limit'])
            ->take($input['limit'])
            ->get();

            return response()->json([
                'data' => $userData,
                'totalOverall' => $totalOverall,
                'totalActive' => $totalActive,
                'totalArchive' => $totalArchive,
                'page' => (int) $input['page'],
                'limit' => (int) $input['limit'],
                'status' => 'success',
            ], 200);
        } catch (Exception $e) {
            return response((array)[
                'data' => $e->getMessage(),
                'file' => $e->getFile(),
                'line_error' => $e->getLine(),
                'message' => "There is an error occured.",
                'status' => 'error'
            ], 500);
        }
    }

    public function AddUser(Request $request) {
        $basic = $request->header('Authorization');
        $split = explode(' ', $basic);
        $user = $this->getPayload($split[1]);

        if(!$user || $user['user_type'] !== 'Admin')
            return response()->json([
                'message' => 'Unauthorized',
                'status' => 'error',
            ], 401);

        try {
            $request->merge([
                'username' => strtolower($request->input('username')),
                'email' => strtolower($request->input('email'))
            ]);

            $validator = Validator::make($request->all(), [
                'username' => 'required|unique:users,username',
                'first_name' => 'required',
                'last_name' => 'required',
                'email' => 'required|email|unique:user_details,email',
                'password' => 'required',
                'user_type' => 'required',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'message' => $validator->errors()->first(),
                    'status' => 'error'
                ], 422);
            }

            $data = $request->only('username', 'first_name', 'last_name', 'email', 'password', 'user_type');
            $data['password'] = bcrypt($data['password']);

            DB::beginTransaction();

            $addUser = User::firstOrCreate([
                'username' => $data['username'],
                'password' => $data['password'],
                'user_type' => $data['user_type']
            ]);

            if (!$addUser) {
                DB::rollback();
                return response()->json([
                    'data' => $addUser,
                    'message' => 'There is an error in adding user.',
                    'status' => 'error',
                ], 422);
            }

            $addUserDetails = UserDetail::firstOrCreate([
                'user_id' => $addUser['id'],
                'first_name' => $data['first_name'],
                'last_name' => $data['last_name'],
                'email' => $data['email'],
                'password' => $data['password'],
            ]);

            if (!$addUserDetails) {
                DB::rollback();
                return response()->json([
                    'data' => $addUserDetails,
                    'message' => 'There is an error in adding user.',
                    'status' => 'error',
                ], 422);
            }

            DB::commit();

            return response()->json([
                'message' => 'Successfully added user!',
                'status' => 'success',
            ], 201);

        } catch (Exception $e) {
            return response((array)[
                'data' => $e->getMessage(),
                'file' => $e->getFile(),
                'line_error' => $e->getLine(),
                'message' => "There is an error occured.",
                'status' => 'error'
            ], 500);
        }
        
    }

    public function UpdateUser(Request $request) {
        $basic = $request->header('Authorization');
        $split = explode(' ', $basic);
        $user = $this->getPayload($split[1]);

        if(!$user || $user['user_type'] !== 'Admin')
            return response()->json([
                'message' => 'Unauthorized',
                'status' => 'error',
            ], 401);
        
        try {
            // Prevent Admin from updating own account if changing Admin > User
            if ($user['user_id'] == $request->route('user_id') && $request->input('user_type') !== 'Admin') {
                return response()->json([
                    'message' => 'Cannot change your own account status while you are still logged in.',
                    'status' => 'error',
                ], 403);
            }

            $request->merge([
                'username' => strtolower($request->input('username')),
                'email' => strtolower($request->input('email'))
            ]);

            $validator = Validator::make($request->all(), [
                'username' => [
                    'required',
                    Rule::unique('users', 'username')->ignore($request->route('user_id')),
                ],
                'first_name' => 'required',
                'last_name' => 'required',
                'email' => [
                    'required',
                    'email',
                    Rule::unique('user_details', 'email')->ignore($request->route('user_id'), 'user_id')
                ],
                'user_type' => 'required',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'message' => $validator->errors()->first(),
                    'status' => 'error'
                ], 422);
            }

            $data = $request->only('username', 'first_name', 'last_name', 'email', 'user_type');
            if ($request->filled('password')) {
                $data['password'] = bcrypt($request->input('password'));
            }

            DB::beginTransaction();

            $updateUser = User::where('id', $request->route('user_id'))->first();
            $updateUser->update($data);
            if (!$updateUser) {
                DB::rollback();
                return response()->json([
                    'data' => $updateUser,
                    'message' => 'There is an error in updating user.',
                    'status' => 'error',
                ], 422);
            }

            $updateUserDetail = UserDetail::where('user_id', $request->route('user_id'))->first();
            $updateUserDetail->update($data);
            if (!$updateUserDetail) {
                DB::rollback();
                return response()->json([
                    'data' => $updateUserDetail,
                    'message' => 'There is an error in updating user.',
                    'status' => 'error',
                ], 422);
            }

            DB::commit();

            return response()->json([
                'message' => 'Successfully updated user!',
                'status' => 'success',
            ], 200);

        } catch (Exception $e) {
            return response((array)[
                'data' => $e->getMessage(),
                'file' => $e->getFile(),
                'line_error' => $e->getLine(),
                'message' => "There is an error occured.",
                'status' => 'error'
            ], 500);
        }
    }

    public function ArchiveUser(Request $request) {
        $basic = $request->header('Authorization');
        $split = explode(' ', $basic);
        $user = $this->getPayload($split[1]);

        if(!$user || $user['user_type'] !== 'Admin')
            return response()->json([
                'message' => 'Unauthorized',
                'status' => 'error',
            ], 401);
        
        try {
            // Prevent Admin from archiving own account while logged in
            if ($user['user_id'] == $request->route('user_id')) {
                return response()->json([
                    'message' => 'Cannot archive your own account while you are still logged in.',
                    'status' => 'error',
                ], 403);
            }

            $archiveUser = User::where('id', $request->route('user_id'))->first();
            $archiveUserDetails = UserDetail::where('user_id', $request->route('user_id'))->first();

            if (!$archiveUser || !$archiveUserDetails) {
                return response()->json([
                    'message' => 'User does not exist.',
                    'status' => 'error',
                ], 404);
            }

            DB::beginTransaction();

            $archiveUser->delete();
            $archiveUserDetails->delete();

            DB::commit();

            return response()->json([
                'message' => 'Successfully archived user!',
                'status' => 'success',
            ], 201);

        } catch (Exception $e) {
            return response((array)[
                'data' => $e->getMessage(),
                'file' => $e->getFile(),
                'line_error' => $e->getLine(),
                'message' => "There is an error occured.",
                'status' => 'error'
            ], 500);
        }
    }

    public function RestoreUser(Request $request) {
        $basic = $request->header('Authorization');
        $split = explode(' ', $basic);
        $user = $this->getPayload($split[1]);

        if(!$user || $user['user_type'] !== 'Admin')
            return response()->json([
                'message' => 'Unauthorized',
                'status' => 'error',
            ], 401);
        
        try {
            $restoreUser = User::onlyTrashed()->where('id', $request->route('user_id'))->first();
            $restoreUserDetails = UserDetail::onlyTrashed()->where('user_id', $request->route('user_id'))->first();

            if (!$restoreUser || !$restoreUserDetails) {
                return response()->json([
                    'message' => 'User does not exist.',
                    'status' => 'error',
                ], 404);
            }

            DB::beginTransaction();

            $restoreUser->restore();
            $restoreUserDetails->restore();

            DB::commit();

            return response()->json([
                'message' => 'Successfully restored user!',
                'status' => 'success',
            ], 201);

        } catch (Exception $e) {
            return response((array)[
                'data' => $e->getMessage(),
                'file' => $e->getFile(),
                'line_error' => $e->getLine(),
                'message' => "There is an error occured.",
                'status' => 'error'
            ], 500);
        }
    }

    public function DeleteUser(Request $request) {
        $basic = $request->header('Authorization');
        $split = explode(' ', $basic);
        $user = $this->getPayload($split[1]);

        if(!$user || $user['user_type'] !== 'Admin')
            return response()->json([
                'message' => 'Unauthorized',
                'status' => 'error',
            ], 401);
        
        try {
            $deleteUser = User::onlyTrashed()->where('id', $request->route('user_id'))->first();
            if (!$deleteUser) {
                return response()->json([
                    'message' => 'User does not exist.',
                    'status' => 'error',
                ], 404);
            }

            DB::beginTransaction();

            $deleteUser->forceDelete();

            DB::commit();

            return response()->json([
                'message' => 'Successfully deleted user!',
                'status' => 'success',
            ], 201);

        } catch (Exception $e) {
            return response((array)[
                'data' => $e->getMessage(),
                'file' => $e->getFile(),
                'line_error' => $e->getLine(),
                'message' => "There is an error occured.",
                'status' => 'error'
            ], 500);
        }
    }
}