<?php

namespace App\Http\Controllers;

use App\Models\User;
use ReallySimpleJWT\Token;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function getPayload($token)
	{
		$payload = Token::getPayload($token, env('ACCESS_TOKEN'));

		$validatePayload = User::where([['id', '=', $payload['user_id']]])->first();

		if(!$validatePayload) {
			return false;
		}
			
		$payload['user_type'] = $validatePayload->user_type;

		return $payload;
	}
}