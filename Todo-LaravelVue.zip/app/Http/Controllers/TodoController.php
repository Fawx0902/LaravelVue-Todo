<?php

namespace App\Http\Controllers;

use App\Models\Todo;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

use Exception;

class TodoController extends Controller
{
    public function GetTodoTable(Request $request) {
        $basic = $request->header('Authorization');
        $split = explode(' ', $basic);
        $user = $this->getPayload($split[1]);

        if(!$user)
            return response()->json([
                'message' => 'Unauthorized',
                'status' => 'error',
            ], 401);
        
        try {
            $input = $request->only('page', 'limit', 'search', 'tabStatus');
            $query = Todo::with(['user' => function ($query) {
                    $query->withTrashed();
                    $query->with('userDetail:id,user_id,first_name,last_name,email');
                }])           
                ->when($input['tabStatus'] !== "All", function ($query) use ($input){
                    $query->where('status', $input['tabStatus']);
                })
                ->orderBy('updated_at', 'desc')
                ->select('*');

            if ($request->filled('search') && strlen($input['search']) >= 2) {
                $search_term = $input['search'];
                $query->where(function ($query) use ($search_term) {
                    $query->orWhere('todo', 'LIKE', '%' . $search_term . '%')
                    ->orWhere('description', 'LIKE', '%' . $search_term . '%');
                });
            }

            // Count totals based on the filtered query
            $totalOverall = $query->count();
            $totalPending = (clone $query)->where('status', 'Pending')->count();
            $totalCompleted = (clone $query)->where('status', 'Completed')->count();
            
            $todoData = $query->skip($input['page'] * $input['limit'])
            ->take($input['limit'])
            ->get();

            return response()->json([
                'data' => $todoData,
                'totalOverall' => $totalOverall,
                'totalPending' => $totalPending,
                'totalCompleted' => $totalCompleted,
                'page' => (int) $input['page'],
                'limit' => (int) $input['limit'],
                'status' => 'success',
            ], 200);
        } catch (Exception $e) {
            return response((array)[
                'data' => $e->getMessage(),
                'file' => $e->getFile(),
                'line_error' => $e->getLine(),
                'message' => "There is an error occured.",
                'status' => 'error'
            ], 500);
        }
    }

    public function AddTodo(Request $request) {
        $basic = $request->header('Authorization');
        $split = explode(' ', $basic);
        $user = $this->getPayload($split[1]);

        if(!$user)
            return response()->json([
                'message' => 'Unauthorized',
                'status' => 'error',
            ], 401);
        
        try {
            $validator = Validator::make($request->all(), [
                'todo' => 'required',
                'user_id' => 'required|exists:users,id',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'message' => $validator->errors()->first(),
                    'status' => 'error',
                ], 422);
            }

            $data = $request->only('todo', 'description', 'user_id');
            if (!$request->filled('description')) {
                $data['description'] = null;
            }

            DB::beginTransaction();
            $addTodo = Todo::firstOrCreate($data);

            if (!$addTodo) {
                DB::rollback();
                return response()->json([
                    'data' => $addTodo,
                    'message' => 'There is an error in adding todo.',
                    'status' => 'error',
                ], 422);
            }

            DB::commit();

            return response()->json([
                'message' => 'Successfully added todo!',
                'status' => 'success',
            ], 201);
        } catch (Exception $e) {
            return response((array)[
                'data' => $e->getMessage(),
                'file' => $e->getFile(),
                'line_error' => $e->getLine(),
                'message' => "There is an error occured.",
                'status' => 'error'
            ], 500);
        }
    }

    public function UpdateTodo(Request $request) {
        $basic = $request->header('Authorization');
        $split = explode(' ', $basic);
        $user = $this->getPayload($split[1]);

        if(!$user)
            return response()->json([
                'message' => 'Unauthorized',
                'status' => 'error',
            ], 401);
        
        try {
            $validator = Validator::make($request->all(), [
                'todo' => 'required',
                'status' => 'required|in:Pending,Completed',
                'user_id' => 'required|exists:users,id',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'message' => $validator->errors()->first(),
                    'status' => 'error',
                ], 422);
            }

            $updateTodo = Todo::where('id', $request->route('todo_id'))->first();
            if ($user['user_type'] !== 'Admin' && $updateTodo['user_id'] !== $user['user_id']) {
                return response()->json([
                    'message' => 'You are forbidden to take this action!',
                    'status' => 'error',
                ], 403);
            }

            $data = $request->only('todo', 'description', 'user_id', 'status');
            if (!$request->filled('description')) {
                $data['description'] = null;
            }

            DB::beginTransaction();

            $updateTodo->update($data);
            if (!$updateTodo) {
                DB::rollback();
                return response()->json([
                    'data' => $updateTodo,
                    'message' => 'There is an error in updating todo.',
                    'status' => 'error',
                ], 422);
            }

            DB::commit();

            return response()->json([
                'message' => 'Successfully updated todo!',
                'status' => 'success',
            ], 200);
        } catch (Exception $e) {
            return response((array)[
                'data' => $e->getMessage(),
                'file' => $e->getFile(),
                'line_error' => $e->getLine(),
                'message' => "There is an error occured.",
                'status' => 'error'
            ], 500);
        }
    }

    public function DeleteTodo(Request $request) {
        $basic = $request->header('Authorization');
        $split = explode(' ', $basic);
        $user = $this->getPayload($split[1]);

        if(!$user)
            return response()->json([
                'message' => 'Unauthorized',
                'status' => 'error',
            ], 401);
        
        try {
            $deleteTodo = Todo::where('id', $request->route('todo_id'))->first();
            if (!$deleteTodo) {
                return response()->json([
                    'message' => 'Todo does not exist.',
                    'status' => 'error',
                ], 404);
            }

            if ($user['user_type'] !== 'Admin' && $deleteTodo['user_id'] !== $user['user_id']) {
                return response()->json([
                    'message' => 'You are forbidden to take this action!',
                    'status' => 'error',
                ], 403);
            }

            DB::beginTransaction();

            $deleteTodo->delete();

            DB::commit();

            return response()->json([
                'message' => 'Successfully deleted todo!',
                'status' => 'success',
            ], 201);
        } catch (Exception $e) {
            return response((array)[
                'data' => $e->getMessage(),
                'file' => $e->getFile(),
                'line_error' => $e->getLine(),
                'message' => "There is an error occured.",
                'status' => 'error'
            ], 500);
        }
    }
}
