<?php

namespace App\Models;
use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Auth\Authenticatable as AuthenticableTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Notifications\Notifiable;

class User extends Model implements Authenticatable
{
    use HasFactory, AuthenticableTrait, Notifiable, SoftDeletes;

    protected $fillable = [
        'username',
        'password',
        'user_type',
    ];

    protected $hidden = [
        'password'
    ];

    public function userDetail() {
        return $this->hasOne(UserDetail::class)
            ->select(['id', 'user_id', 'first_name', 'last_name', 'email']);;
    }
    
    public function todos() {
        return $this->hasMany(Todo::class)
            ->select(['id', 'user_id', 'todo', 'description', 'status']);;
    }
}