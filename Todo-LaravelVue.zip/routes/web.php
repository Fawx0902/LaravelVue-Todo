<?php

use Illuminate\Support\Facades\Route;

Route::get('/{any}', function () {
    return view('welcome'); // Adjust if your Vue app's main file is named differently
})->where('any', '.*');