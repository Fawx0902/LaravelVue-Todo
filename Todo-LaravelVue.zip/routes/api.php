<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\TodoController;

use App\Http\Middleware\VerifyUserToken;
use App\Http\Middleware\VerifyUserAPIKey;

Route::get('/example', function () {
    return response()->json(['message' => 'This is an example API route']);
});

Route::middleware('api')->group(function () {
    Route::post('/user/login', [UserController::class, 'loginUser']);

    Route::middleware([VerifyUserToken::class, VerifyUserAPIKey::class])->group(function () {
        Route::get('/user/profile', [UserController::class, 'userProfile'])->name('user-profile');
        Route::post('/user/list', [UserController::class, 'GetUserTable'])->name('user-table');
        Route::post('/user/add', [UserController::class, 'AddUser'])->name('add-user');
        Route::post('/user/update/{user_id}', [UserController::class, 'UpdateUser'])->name('update-user');
        Route::put('/user/archive/{user_id}', [UserController::class, 'ArchiveUser'])->name('archive-user');
        Route::put('/user/restore/{user_id}', [UserController::class, 'RestoreUser'])->name('restore-user');
        Route::delete('/user/delete/{user_id}', [UserController::class, 'DeleteUser'])->name('delete-user');

        Route::post('/todo/list', [TodoController::class, 'GetTodoTable'])->name('todo-table');
        Route::post('/todo/add', [TodoController::class, 'AddTodo'])->name('add-todo');
        Route::post('/todo/update/{todo_id}', [TodoController::class, 'UpdateTodo'])->name('update-todo');
        Route::delete('/todo/delete/{todo_id}', [TodoController::class, 'DeleteTodo'])->name('delete-todo');
    });
});
