import { createApp } from 'vue'
import router from './router'
import Toast from 'vue-toastification';
import 'vue-toastification/dist/index.css';

import HeaderComponent from './components/HeaderComponent.vue'
import SidebarComponent from './components/SidebarComponent.vue'

const app = createApp({})

app.component('header-component', HeaderComponent)
app.component('sidebar-component', SidebarComponent)

app.use(router)
app.use(Toast, {
    maxToasts: 1
});

app.mount('#app')