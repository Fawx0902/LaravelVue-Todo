function FormConverter(data) {
    const form = new FormData();
  
    Object.entries(data).forEach(([key, value]) => {
      if (Array.isArray(value)) {
        value.forEach((item) => {
          form.append(`${key}[]`, item);
        });
      } else if (typeof value === 'object' && value !== null && !isFile(value)) {
        form.append(key, JSON.stringify(value));
      } else {
        form.append(key, value);
      }
    });
  
    return form;
  }
  
  function isFile(value) {
    return value instanceof File || value instanceof Blob;
  }
  
  export default FormConverter;