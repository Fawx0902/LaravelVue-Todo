<template>
  <div className="bg-neutral-800 flex flex-col items-center justify-center min-h-screen py-2">
    <div className="bg-white w-11/12 md:w-9/12 max-w-2xl p-5 rounded-xl">
      <h1 class="text-3xl font-bold underline">Hello world!</h1>
    </div>
  </div>
</template>

<script>
export default {
  mounted() {
    console.log('Component mounted.')
  }
}
</script>
