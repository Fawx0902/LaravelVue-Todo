<template>
  <div class="flex h-screen bg-gray-100">
    <!-- Loading screen -->
    <div v-if="loading" class="fixed inset-0 z-50 flex items-center justify-center bg-white">
      <div class="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-gray-900"></div>
      <p class="ml-4 text-lg font-semibold">Loading...</p>
    </div>

    <!-- Sidebar toggle button for small screens -->
    <button @click="toggleSidebar" class="fixed left-3 top-3 z-40 p-4 text-black lg:hidden">
      <svg
        xmlns="http://www.w3.org/2000/svg"
        class="h-6 w-6"
        viewBox="0 0 24 24"
        stroke="currentColor"
        fill="none"
      >
        <path
          stroke-linecap="round"
          stroke-linejoin="round"
          stroke-width="2.5"
          d="M4 6h16M4 12h16M4 18h16"
        />
      </svg>
    </button>

    <!-- Sidebar component -->
    <sidebar-component
      :isSidebarOpen="isSidebarOpen"
      @toggleSidebar="toggleSidebar"
    ></sidebar-component>

    <!-- Main content -->
    <div class="flex flex-1 flex-col overflow-hidden">
      <header-component></header-component>
      <main class="flex-1 overflow-y-auto overflow-x-hidden bg-gray-300 p-4">
        <router-view></router-view>
      </main>
    </div>

    <!-- Overlay for small screens when sidebar is open -->
    <div
      v-if="isSidebarOpen"
      class="fixed inset-0 z-30 bg-black bg-opacity-50 lg:hidden"
      @click="toggleSidebar"
    ></div>
  </div>
</template>

<script setup>
import { ref, onMounted, provide } from 'vue'
import axios from '../axios'

const user = ref({})
const isSidebarOpen = ref(false)
const loading = ref(true)

const fetchProfile = async () => {
  try {
    const response = await axios.get('/api/user/profile', {
      headers: {
        'x-api-key': 'Pr0j3cTS3k@1'
      }
    })
    user.value = response.data.data
    localStorage.setItem('currentUser', JSON.stringify(user.value))
  } catch (error) {
    console.error('Error fetching user data:', error)
  } finally { 
    loading.value = false
  }
}

const toggleSidebar = () => {
  isSidebarOpen.value = !isSidebarOpen.value
}

provide('currentUser', user);

onMounted(() => {
  fetchProfile()
});
</script>
