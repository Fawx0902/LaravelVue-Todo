<template>
  <div
    v-if="isOpen"
    class="fixed inset-0 z-50 overflow-y-auto"
    aria-labelledby="modal-title"
    role="dialog"
    aria-modal="true"
  >
    <div class="flex min-h-screen items-center justify-center px-4 pb-20 pt-4 text-center sm:p-0">
      <div
        class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity"
        aria-hidden="true"
        @click="closeModal"
      ></div>

      <span class="hidden sm:inline-block sm:h-screen sm:align-middle" aria-hidden="true"
        >&#8203;</span
      >

      <div
        class="inline-block transform overflow-hidden rounded-lg bg-white text-left align-bottom shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-lg sm:align-middle"
      >
        <div class="bg-white px-4 pb-4 pt-5 sm:p-6 sm:pb-4">
          <h1 class="text-center text-lg font-bold">
            {{ props.type }}
          </h1>

          <!-- Form fields -->
          <div class="mt-4 space-y-4">
            <div>
              <label for="username" class="mb-2 block text-sm font-medium text-gray-700"
                >Username</label
              >
              <input
                v-model="props.userData.username"
                id="username"
                type="text"
                class="mt-1 block border w-full rounded-md py-2 pl-2 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                :class="[
                    {
                        'border-gray-300': !errors.username,
                        'border-red-600': errors.username,
                    }
                ]"
              />
              <div v-if="errors.username" class="text-red-600">Username is required.</div>
            </div>

            <div>
              <label for="first_name" class="mb-2 block text-sm font-medium text-gray-700"
                >First Name</label
              >
              <input
                v-model="props.userData.first_name"
                id="first_name"
                type="text"
                :class="[
                    'mt-1 block border w-full rounded-md py-2 pl-2 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm',
                    {
                        'border-gray-300': !errors.first_name,
                        'border-red-600': errors.first_name,
                    }
                ]"
              />
              <div v-if="errors.first_name" class="text-red-600">First Name is required.</div>
            </div>

            <div>
              <label for="last_name" class="mb-2 block text-sm font-medium text-gray-700"
                >Last Name</label
              >
              <input
                v-model="props.userData.last_name"
                id="last_name"
                type="text"
                :class="[
                    'mt-1 block border w-full rounded-md py-2 pl-2 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm',
                    {
                        'border-gray-300': !errors.last_name,
                        'border-red-600': errors.last_name,
                    }
                ]"
              />
              <div v-if="errors.last_name" class="text-red-600">Last Name is required.</div>
            </div>

            <div>
              <label for="email" class="mb-2 block text-sm font-medium text-gray-700">Email</label>
              <input
                v-model="props.userData.email"
                id="email"
                type="email"
                :class="[
                    'mt-1 block border w-full rounded-md py-2 pl-2 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm',
                    {
                        'border-gray-300': !errors.email,
                        'border-red-600': errors.email,
                    }
                ]"
              />
              <div v-if="errors.email" class="text-red-600">Email is required.</div>
            </div>

            <div>
              <label for="password" class="mb-2 block text-sm font-medium text-gray-700">
                {{ isEditMode ? 'Change Password (Optional)' : 'Password' }}
              </label>
              <input
                v-model="props.userData.password"
                id="password"
                type="password"
                :class="[
                    'mt-1 block border w-full rounded-md py-2 pl-2 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm',
                    {
                        'border-gray-300': !errors.password,
                        'border-red-600': errors.password,
                    }
                ]"
                :placeholder="isEditMode ? 'Leave Empty to keep Original Password' : ''"
              />
              <div v-if="errors.password" class="text-red-600">Password is required.</div>
            </div>

            <div class="relative">
              <label for="user_type" class="mb-2 block text-sm font-medium text-gray-700"
                >User Type</label
              >
              <select
                v-model="props.userData.user_type"
                id="user_type"
                type="user_type"
                :class="[
                    'mt-1 block border w-full appearance-none rounded-md py-2 pl-2 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm',
                    {
                        'border-gray-300': !errors.user_type,
                        'border-red-600': errors.user_type,
                    }
                ]"
              >
                <option value="">Select Type</option>
                <option value="User">User</option>
                <option value="Admin">Admin</option>
              </select>
              <div
                class="pointer-events-none absolute inset-y-12 right-0 flex items-center pr-2 text-gray-700"
              >
                <svg
                  class="h-4 w-4 fill-current"
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 20 20"
                >
                  <path
                    d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"
                  />
                </svg>
              </div>
              <div v-if="errors.user_type" class="text-red-600">User Type is required.</div>
            </div>
          </div>
        </div>

        <!-- Buttons -->
        <div class="bg-gray-50 px-4 py-3 sm:flex sm:flex-row-reverse sm:px-6">
          <button
            @click="handleSubmit"
            type="button"
            :class="[
              'inline-flex w-full justify-center rounded-md border border-transparent px-4 py-2 text-base font-medium text-white shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 sm:ml-3 sm:w-auto sm:text-sm',
              {
                'bg-sky-600 hover:bg-sky-700 focus:ring-sky-500': isEditMode,
                'bg-blue-600 hover:bg-blue-700 focus:ring-blue-500': !isEditMode,
                'cursor-not-allowed opacity-50': loading
              }
            ]"
            :disabled="loading"
          >
            <span v-if="loading">Processing...</span>
            <span v-else>{{ isEditMode ? 'Update' : 'Submit' }}</span>
          </button>

          <button
            @click="closeModal"
            type="button"
            class="mt-3 inline-flex w-full justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-base font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 sm:ml-3 sm:mt-0 sm:w-auto sm:text-sm"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useToast } from 'vue-toastification'

const props = defineProps({
  isOpen: Boolean,
  userData: Object,
  type: String,
  loading: Boolean,
  isEditMode: Boolean
})

const toast = useToast()
const errors = ref({})

const validateField = () => {
  errors.value = {}
  const fields = ['username', 'first_name', 'last_name', 'email', 'user_type']
  let isFilled = true

  fields.forEach((field) => {
    if (!props.userData[field]) {
      errors.value[field] = true
      isFilled = false
    }
  })

  // Additional validation for password when adding a new user
  if (!props.isEditMode && !props.userData['password']) {
    errors.value['password'] = true
    isFilled = false
  }

  if (!isFilled) {
    toast.error('Please fill up fields.', {
      position: 'top-center'
    })
  }

  return isFilled
}

const handleSubmit = () => {
  if (validateField()) {
    confirmSubmit()
  }
}

const emit = defineEmits(['close', 'confirm'])

const closeModal = () => {
  errors.value = {}
  emit('close')
}

const confirmSubmit = () => {
  emit('confirm')
};
</script>
