<template>
  <div class="flex items-center justify-center py-20 w-full">
    <svg
      class="h-10 w-10 animate-spin text-blue-500"
      xmlns="http://www.w3.org/2000/svg"
      fill="none"
      viewBox="0 0 24 24"
      stroke="currentColor"
    >
      <path
        stroke-linecap="round"
        stroke-linejoin="round"
        stroke-width="2"
        d="M12 4.75v14.5M19.25 12H4.75"
      />
    </svg>
    <p class="ml-2 text-xl font-semibold text-gray-700">{{ message }}</p>
  </div>
</template>

<script setup>
defineProps({
  message: {
    type: String,
    default: 'Loading data...'
  }
});
</script>