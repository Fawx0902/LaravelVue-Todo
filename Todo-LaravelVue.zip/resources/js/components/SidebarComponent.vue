<template>
  <div>
    <!-- Sidebar for large screens, always visible -->
    <div class="hidden min-h-screen w-64 flex-col bg-gray-900 px-3 text-gray-300 lg:block">
      <router-link to="/todo" class="flex items-center px-4 py-4">
        <img src="/images/logo.png" alt="Bird Logo" class="h-12 w-12" />
        <span class="text-xl font-semibold text-white">User-Todo</span>
      </router-link>

      <div>
        <div class="text-md my-4 px-2 uppercase text-gray-600">Menu</div>
        <nav class="space-y-2">
          <router-link
            to="/todo"
            class="flex items-center space-x-2 rounded px-2 py-2 hover:bg-gray-800"
            :class="isActive('/todo') ? 'bg-gray-800 text-white' : 'hover:bg-gray-800'"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              class="h-5 w-5"
              viewBox="0 0 20 20"
              fill="currentColor"
            >
              <path
                d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"
              />
            </svg>
            <span>Todo</span>
          </router-link>
          <router-link
            v-if="currentUser.user_type == 'Admin'"
            to="/user"
            class="flex items-center space-x-2 rounded px-2 py-2 hover:bg-gray-800"
            :class="isActive('/user') ? 'bg-gray-800 text-white' : 'hover:bg-gray-800'"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              class="h-5 w-5"
              viewBox="0 0 20 20"
              fill="currentColor"
            >
              <path
                fill-rule="evenodd"
                d="M10 2a4 4 0 100 8 4 4 0 000-8zm-7 14a7 7 0 0114 0H3z"
                clip-rule="evenodd"
              />
            </svg>
            <span>User</span>
          </router-link>
        </nav>
      </div>
    </div>

    <!-- Sidebar for small and medium screens, toggled with hamburger menu -->
    <div
      class="fixed inset-y-0 left-0 z-40 flex min-h-screen w-64 transform flex-col bg-gray-900 px-3 text-gray-300 transition-transform duration-300 lg:hidden"
      :class="{ '-translate-x-full': !isSidebarOpen, 'translate-x-0': isSidebarOpen }"
    >
      <router-link to="/todo" class="flex items-center px-4 py-4">
        <img src="/images/logo.png" alt="Bird Logo" class="h-12 w-12" />
        <span class="text-xl font-semibold text-white">User-Todo</span>
        <button @click="toggleSidebar" class="px-5 text-white lg:hidden">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            class="h-6 w-6"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="2"
              d="M19 12H5M12 5l-7 7 7 7"
            />
          </svg>
        </button>
      </router-link>

      <div>
        <div class="text-md my-4 px-2 uppercase text-gray-600">Menu</div>
        <nav class="space-y-2">
          <router-link
            to="/todo"
            class="flex items-center space-x-2 rounded px-2 py-2 hover:bg-gray-800"
            :class="isActive('/todo') ? 'bg-gray-800 text-white' : 'hover:bg-gray-800'"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              class="h-5 w-5"
              viewBox="0 0 20 20"
              fill="currentColor"
            >
              <path
                d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"
              />
            </svg>
            <span>Todo</span>
          </router-link>
          <router-link
            v-if="currentUser.user_type == 'Admin'"
            to="/user"
            class="flex items-center space-x-2 rounded px-2 py-2 hover:bg-gray-800"
            :class="isActive('/user') ? 'bg-gray-800 text-white' : 'hover:bg-gray-800'"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              class="h-5 w-5"
              viewBox="0 0 20 20"
              fill="currentColor"
            >
              <path
                fill-rule="evenodd"
                d="M10 2a4 4 0 100 8 4 4 0 000-8zm-7 14a7 7 0 0114 0H3z"
                clip-rule="evenodd"
              />
            </svg>
            <span>User</span>
          </router-link>
        </nav>
      </div>
    </div>
  </div>
</template>

<script setup>
import { inject } from 'vue'
import { useRoute } from 'vue-router';

const currentUser = inject('currentUser')

const props = defineProps({
  isSidebarOpen: {
    type: Boolean,
    default: false
  },
});

const emit = defineEmits(['toggleSidebar']);
const route = useRoute();

const isActive = (routePath) => {
  return route.path.startsWith(routePath);
};

const toggleSidebar = () => {
  emit('toggleSidebar');
};
</script>

<style scoped>
/* You can add custom styles here */
</style>
