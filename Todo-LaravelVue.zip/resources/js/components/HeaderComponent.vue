<template>
  <header class="flex items-center justify-end bg-white p-4 shadow-md">
    <!-- User profile -->
    <div class="flex items-center space-x-4">
      <div class="relative mr-16 hidden sm:block">
        <input
          type="text"
          placeholder="Type to search..."
          class="w-60 rounded-md border-none bg-white py-3 pl-10 focus:outline-none"
        />
        <svg
          class="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 transform text-gray-500"
          fill="currentColor"
          viewBox="0 0 20 20"
        >
          <path
            fill-rule="evenodd"
            d="M12.9 14.32a8 8 0 111.42-1.42l4.77 4.77a1 1 0 01-1.42 1.42l-4.77-4.77zM16 8a6 6 0 11-12 0 6 6 0 0112 0z"
            clip-rule="evenodd"
          />
        </svg>
      </div>
      <!-- Notification icons -->
      <div class="flex space-x-4">
        <button class="text-gray-500 hover:text-gray-700 focus:outline-none">
          <svg
            class="h-6 w-6"
            fill="none"
            viewBox="0 0 24 24"
            stroke-width="1.5"
            stroke="currentColor"
            aria-hidden="true"
          >
            <path
              stroke-linecap="round"
              stroke-linejoin="round"
              d="M14.857 17.082a23.848 23.848 0 005.454-1.31A8.967 8.967 0 0118 9.75v-.7V9A6 6 0 006 9v.75a8.967 8.967 0 01-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 01-5.714 0m5.714 0a3 3 0 11-5.714 0"
            />
          </svg>
        </button>
      </div>

      <!-- User profile dropdown -->
      <Menu as="div" class="relative ml-3">
        <div>
          <MenuButton class="flex items-center space-x-3 focus:outline-none">
            <div class="hidden flex-col items-end md:flex">
              <span class="font-medium text-gray-700">{{ currentUser?.user_detail?.first_name || 'John' }} {{ currentUser?.user_detail?.last_name || 'Doe' }}</span>
              <span class="text-sm text-gray-500">{{ currentUser?.user_type || 'Ghost' }}</span>
            </div>
            <div
              class="relative z-10 block h-12 w-12 overflow-hidden rounded-full border-2 border-gray-300"
            >
              <img
                class="h-full w-full object-cover"
                src="/images/default_pfp.png"
                alt="User Avatar"
              />
            </div>
          </MenuButton>
        </div>
        <transition
          enter-active-class="transition ease-out duration-100"
          enter-from-class="transform opacity-0 scale-95"
          enter-to-class="transform opacity-100 scale-100"
          leave-active-class="transition ease-in duration-75"
          leave-from-class="transform opacity-100 scale-100"
          leave-to-class="transform opacity-0 scale-95"
        >
          <MenuItems
            class="absolute right-3 z-10 mt-2 w-48 origin-top-right rounded-md bg-white py-1 shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none"
          >
            <MenuItem v-slot="{ active }">
              <button
                :class="[
                  active ? 'bg-gray-200' : '',
                  'text-md block w-full px-4 py-2 text-left text-gray-700'
                ]"
              >
                Profile
              </button>
            </MenuItem>
            <MenuItem v-slot="{ active }">
              <button
                @click="logout"
                :class="[
                  active ? 'bg-gray-200' : '',
                  'text-md block w-full px-4 py-2 text-left text-gray-700'
                ]"
              >
                Logout
              </button>
            </MenuItem>
          </MenuItems>
        </transition>
      </Menu>
    </div>
  </header>
</template>

<script setup>
import { inject } from 'vue'
import { Menu, MenuButton, MenuItem, MenuItems } from '@headlessui/vue';
import { useRouter } from 'vue-router';

const currentUser = inject('currentUser')

const router = useRouter();

const logout = async () => {
  try {
    localStorage.removeItem('token');
    localStorage.removeItem('currentUser');
    await router.replace('/');
  } catch (error) {
    console.error('Logout error:', error);
    localStorage.removeItem('token');
    localStorage.removeItem('currentUser');
    await router.replace('/');
  }
};
</script>
