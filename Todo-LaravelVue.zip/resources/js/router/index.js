import { createRouter, createWebHistory } from 'vue-router'

const routes = [
  {
    path: '/',
    redirect: '/login' // Redirect from root to /login
  },
  {
    path: '/login',
    name: 'Login',
    component: () => import('../pages/Login.vue'),
    beforeEnter: (to, from, next) => {
      const isAuthenticated = !!localStorage.getItem('token')
      if (isAuthenticated) {
        next('/todo')
      } else {
        next()
      }
    }
  },
  {
    path: '/todo',
    component: () => import('../components/MainLayout.vue'),
    children: [
      {
        path: '/todo',
        name: 'TodoTable',
        component: () => import('../pages/TodoTable.vue'),
        meta: { requiresAuth: true }
      },
      {
        path: '/user',
        name: 'UserTable',
        component: () => import('../pages/UserTable.vue'),
        meta: { requiresAuth: true, requiresAdmin: true }
      },
    ]
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

router.beforeEach((to, from, next) => {
  const isAuthenticated = !!localStorage.getItem('token')
  const currentUser = localStorage.getItem('currentUser')
    ? JSON.parse(localStorage.getItem('currentUser'))
    : null
  
    if (to.matched.some((record) => record.meta.requiresAuth) && !isAuthenticated) {
      next('/')
    }
    else if (to.matched.some((record) => record.meta.requiresAdmin) && currentUser?.user_type !== 'Admin') {
      next('/todo') // Redirect non-admin users to the TodoTable page
    } else {
      next()
    }
})

export default router
