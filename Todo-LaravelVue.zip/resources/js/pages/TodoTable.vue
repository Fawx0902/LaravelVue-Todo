<template>
    <div class="mx-auto w-full max-w-screen-xl px-2">
      <!-- Total Cards -->
      <div class="grid w-full grid-cols-1 gap-4 pb-5 md:grid-cols-2 lg:grid-cols-3">
        <div
          class="flex h-auto flex-col items-center justify-between rounded-lg bg-white p-6 shadow-lg"
        >
          <h3 class="text-black-300 mb-2 text-sm font-semibold">Total Todos</h3>
          <p class="mb-1 text-2xl font-bold text-cyan-500">{{ totalOverall || 0 }}</p>
        </div>
        <div
          class="flex h-auto flex-col items-center justify-between rounded-lg bg-white p-6 shadow-lg"
        >
          <h3 class="text-black-300 mb-2 text-sm font-semibold">Total Completed Todos</h3>
          <p class="mb-1 text-2xl font-bold text-green-500">{{ totalCompleted || 0 }}</p>
        </div>
        <div
          class="flex h-auto flex-col items-center justify-between rounded-lg bg-white p-6 shadow-lg"
        >
          <h3 class="text-black-300 mb-2 text-sm font-semibold">Total Pending Todos</h3>
          <p class="mb-1 text-2xl font-bold text-orange-500">{{ totalPending || 0 }}</p>
        </div>
      </div>
      <div class="overflow-hidden rounded-lg bg-white shadow-lg">
        <!-- Search, Add Button, Filter -->
        <div class="flex flex-col md:flex-row items-start md:items-center justify-between space-y-2 md:space-y-0 md:space-x-4 border-b border-gray-200 p-4">
          <div class="relative w-full md:max-w-md flex-grow">
            <input
              name="search"
              type="text"
              placeholder="Search ID, Name, Description"
              v-model="search"
              @input="debouncedSearch"
              class="w-full rounded-md border border-gray-300 py-2 pl-10 pr-4 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
            <div class="absolute inset-y-0 left-0 flex items-center pl-3">
              <svg
                class="h-5 w-5 text-gray-400"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 20 20"
                fill="currentColor"
              >
                <path
                  fill-rule="evenodd"
                  d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z"
                  clip-rule="evenodd"
                />
              </svg>
            </div>
          </div>
  
          <div class="flex flex-wrap md:flex-nowrap items-start md:items-center justify-start md:justify-end space-y-2 md:space-y-0 md:space-x-2 w-full md:w-auto">
            <button
              class="flex items-center w-full md:w-auto rounded-md bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
              @click="addTodo()"
            >
              <svg
                class="mr-2 h-5 w-5"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 20 20"
                fill="currentColor"
              >
                <path
                  fill-rule="evenodd"
                  d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z"
                  clip-rule="evenodd"
                />
              </svg>
              Add Todo
            </button>
            <div class="relative w-full md:w-auto">
              <select
                name="status"
                v-model="tabStatus"
                @change="changeTabStatus(tabStatus)"
                class="appearance-none w-full md:w-auto rounded-md border border-gray-300 py-2 pl-3 pr-10 focus:outline-none"
              >
                <option value="All">Status</option>
                <option value="Pending">Pending</option>
                <option value="Completed">Completed</option>
              </select>
              <div
                class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700"
              >
                <svg
                  class="h-4 w-4 fill-current"
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 20 20"
                >
                  <path
                    d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"
                  />
                </svg>
              </div>
            </div>
          </div>
        </div>
  
        <!-- Table -->
        <div class="overflow-x-auto">
          <table class="w-full text-left text-sm text-gray-500">
            <thead class="bg-gray-50 text-xs uppercase text-gray-700">
              <tr>
                <th scope="col" class="px-6 py-3">Todo</th>
                <th scope="col" class="px-6 py-3">Description</th>
                <th scope="col" class="px-6 py-3">Status</th>
                <th scope="col" class="px-6 py-3">Created By</th>
                <th scope="col" class="px-6 py-3">Actions</th>
              </tr>
            </thead>
            <tbody v-if="!loadingTable">
              <tr
                v-for="todo in todoTable"
                :key="todo.id"
                class="border-b bg-white hover:bg-gray-50"
              >
                <td class="flex items-center px-6 py-4">
                  <img
                    :src="
                      todo.status == 'Pending'
                        ? '/images/pending.png'
                        : '/images/check.png'
                    "
                    :alt="todo.status"
                    class="mr-3 h-10 w-10 rounded-full object-cover"
                  />
                  <div>
                    <div class="font-medium text-gray-900">{{ todo.todo }}</div>
                    <div class="text-sm text-gray-500">{{ todo.id }}</div>
                  </div>
                </td>
                <td class="px-6 py-4">{{ todo.description || 'No Description Provided' }}</td>
                <td class="px-6 py-4">
                  <span
                    :class="[
                      'rounded-full px-2 py-1 text-xs font-semibold',
                      todo.status == 'Pending'
                        ? 'bg-orange-100 text-orange-800'
                        : 'bg-green-100 text-green-800'
                    ]"
                  >
                    {{ todo.status }}
                  </span>
                </td>
                <td class="px-6 py-4">{{ todo.user.user_detail.first_name }} {{ todo.user.user_detail.last_name }}</td>
                <td class="px-6 py-4">
                  <div>
                    <button
                      @click="updateTodo(todo)"
                      class="mr-2"
                      :class="{
                        'text-gray-500 cursor-not-allowed': todo.user_id !== currentUser.id && currentUser.user_type !== 'Admin',
                        'text-blue-600 hover:text-blue-900': todo.user_id === currentUser.id || currentUser.user_type === 'Admin'
                      }"
                      :disabled="todo.user_id !== currentUser.id && currentUser.user_type !== 'Admin'"
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        class="h-5 w-5"
                        viewBox="0 0 20 20"
                        fill="currentColor"
                      >
                        <path
                          d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z"
                        />
                      </svg>
                    </button>
                    <button
                      @click="deleteTodo('Delete', todo.id)"
                      :class="{
                        'text-gray-500 cursor-not-allowed': todo.user_id !== currentUser.id && currentUser.user_type !== 'Admin',
                        'text-red-600 hover:text-red-900': todo.user_id === currentUser.id || currentUser.user_type === 'Admin'
                      }"
                      :disabled="todo.user_id !== currentUser.id && currentUser.user_type !== 'Admin'"
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        class="h-5 w-5"
                        viewBox="0 0 20 20"
                        fill="currentColor"
                      >
                        <path
                          fill-rule="evenodd"
                          d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z"
                          clip-rule="evenodd"
                        />
                      </svg>
                    </button>
                  </div>
                </td>
              </tr>
            </tbody> 
          </table>
        </div>
        
        <!-- Loading Overlay -->
        <LoadingTable v-if="loadingTable" message="Loading data..." />

        <!-- Pagination -->
        <Pagination
          :currentPage="page + 1"
          :pageSize="limit"
          :totalItems="totalOverall"
          @changePage="handlePageChange"
          @changeLimit="handleLimitChange"
        />
      </div>
      <ConfirmationModal
        :isOpen="isActionModalOpen"
        :action="modalAction"
        :id="selectedTodoID"
        :type="modalType"
        :loading="loadingModal"
        @close="closeActionModal"
        @confirm="handleActionConfirm"
      />
      <TodoModal
        :isOpen="isTodoModalOpen"
        :todoData="todoData"
        :type="modalType"
        :loading="loadingModal"
        :isEditMode="isEditMode"
        @close="closeTodoModal"
        @confirm="handleConfirm"
      />
    </div>
</template>
  
<script setup>
import axios from '../axios'
import { ref, reactive, onMounted, watch, inject } from 'vue'
import { useToast } from 'vue-toastification'
import LoadingTable from '../components/Tables/LoadingTable.vue'
import Pagination from '../components/Tables/Pagination.vue'
import ConfirmationModal from '../components/ConfirmationModal.vue'
import TodoModal from '../components/Modals/TodoModal.vue'

const toast = useToast()
const currentUser = inject('currentUser')

const todoTable = ref([])
const search = ref('')
const tabStatus = ref('All')
const page = ref(0)
const limit = ref(5)
const totalOverall = ref(0)
const totalPending = ref(0)
const totalCompleted = ref(0)
const loadingTable = ref(false)
const timeout = ref(null)

const isActionModalOpen = ref(false)
const modalAction = ref('')
const selectedTodoID = ref('')

const isTodoModalOpen = ref(false)
const todoData = reactive({
  todo: '',
  description: '',
  status: '',
  user_id: currentUser.value.id,
})
const isEditMode = ref(false)

const modalType = ref('') // Signify Add/Update <Module>
const loadingModal = ref(false)

const fetchTable = async () => {
  loadingTable.value = true
  try {
    const response = await axios.post(
      '/api/todo/list',
      {
        page: page.value,
        limit: limit.value,
        search: search.value,
        tabStatus: tabStatus.value,
      },
      {
        headers: {
          'x-api-key': 'Pr0j3cTS3k@1'
        }
      }
    )

    const {
      data: {
        data: todos,
        totalOverall: overall,
        totalPending: pending,
        totalCompleted: complete
      }
    } = response

    todoTable.value = todos
    totalOverall.value = overall
    totalPending.value = pending
    totalCompleted.value = complete
  } catch (error) {
    toast.error('Error fetching data!', {
      position: 'top-center'
    })
    console.error('Error fetching data!', error)
  } finally {
    loadingTable.value = false
  }
}

const changeTabStatus = (status) => {
  tabStatus.value = status
  page.value = 0
  fetchTable()
}

const handlePageChange = (newPage) => {
  page.value = newPage - 1
  fetchTable()
}

const handleLimitChange = (newLimit) => {
  limit.value = Number(newLimit)
  page.value = 0
  fetchTable()
}

const debouncedSearch = () => {
  if (timeout.value) {
    clearTimeout(timeout.value)
  }
  timeout.value = setTimeout(() => {
    fetchTable()
  }, 500)
}

watch(search, () => {
  debouncedSearch()
  page.value = 0
})

const addTodo = () => {
  Object.assign(todoData, {
    todo: '',
    description: '',
    status: '',
    user_id: currentUser.value.id,
  });
  modalType.value = 'Add Todo'
  isEditMode.value = false
  isTodoModalOpen.value = true
}

const updateTodo = (todo) => {
  Object.assign(todoData, {
    todo: todo.todo,
    description: todo.description,
    status: todo.status,
    user_id: todo.user_id,
  });
  selectedTodoID.value = todo.id
  modalType.value = 'Update Todo'
  isEditMode.value = true
  isTodoModalOpen.value = true
}

const deleteTodo = (action, id) => {
  modalAction.value = action
  modalType.value = 'Todo ID'
  selectedTodoID.value = id
  isActionModalOpen.value = true
}

const closeTodoModal = () => {
  isTodoModalOpen.value = false
}

const closeActionModal = () => {
  isActionModalOpen.value = false
}

const handleConfirm = async () => {
  loadingModal.value = true
  const url = isEditMode.value ? `/api/todo/update/${selectedTodoID.value}` : '/api/todo/add'
  try {
    const response = await axios.post(url, todoData, {
      headers: {
        'x-api-key': 'Pr0j3cTS3k@1'
      }
    })

    const { data } = response

    if (data.status !== 'error') {
      toast.success(data.message, { position: 'top-center' })
      fetchTable()
      closeTodoModal()
    } else {
      toast.error(data.message, {
        position: 'top-center'
      })
    }
  } catch (error) {
    console.error('Failed to submit Todo: ', error)
    toast.error(error?.response?.data?.message || 'Something went wrong, please try again!', {
      position: 'top-center'
    })
  } finally {
    loadingModal.value = false
  }
}

const handleActionConfirm = async () => {
  loadingModal.value = true
  try {
    let endpoint = ''
    let method = ''
    let config = {
      headers: {
        'x-api-key': 'Pr0j3cTS3k@1'
      }
    }

    method = axios.delete
    endpoint = `/api/todo/delete/${selectedTodoID.value}`

    let response = await method(endpoint, config)

    const { data } = response

    if (data.status !== 'error') {
      toast.success(data.message, { position: 'top-center' })
      fetchTable()
    } else {
      toast.error(data.message, {
        position: 'top-center'
      })
    }
  } catch (error) {
    toast.error(error?.response?.data?.message || 'Error updating todo, please try again!', {
      position: 'top-center'
    })
    console.error(`Error updating todo: `, error)
  } finally {
    loadingModal.value = false
    closeActionModal()
  }
}

onMounted(() => {
  fetchTable()
});
</script>