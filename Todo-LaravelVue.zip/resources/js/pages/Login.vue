<template>
  <!-- Loading Screen -->
  <div v-if="isLoading" class="fixed inset-0 z-50 flex items-center justify-center bg-white">
    <div class="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-gray-900"></div>
    <p class="ml-4 text-lg font-semibold">Loading...</p>
  </div>

  <div class="flex min-h-screen">
    <!-- Left Section: Background Image -->
    <div
      class="hidden bg-cover bg-center lg:block lg:w-1/2"
      style="background-image: url('/images/login_background.jpg')"
    ></div>
    <!-- Right Section: Login Form -->
    <div class="flex w-full flex-col items-center justify-center bg-white p-8 lg:w-1/2">
      <div class="w-full max-w-md">
        <h1 class="mb-6 text-3xl font-bold">Login Form</h1>
        <!-- Login Form -->
        <form @submit.prevent="login">
          <div v-if="errorMessage" class="mb-4 text-red-600">
            {{ errorMessage }}
          </div>
          <div class="mb-4">
            <label class="text-md font-medium text-gray-700" for="username">Username</label>
            <input
              type="text"
              name="username"
              id="username"
              v-model="username"
              class="mt-1 w-full rounded-md border border-gray-300 px-3 py-3 shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-indigo-500"
              placeholder="johndoe"
            />
          </div>
          <div class="mb-4">
            <label class="text-md font-medium text-gray-700" for="password">Password</label>
            <input
              type="password"
              name="password"
              id="password"
              v-model="password"
              class="mt-1 w-full rounded-md border border-gray-300 px-3 py-3 shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-indigo-500"
              placeholder="Enter Password"
            />
          </div>
          <div class="mb-4 flex items-center justify-between">
            <label class="flex items-center">
              <input
                type="checkbox"
                name="rememberMe"
                v-model="rememberMe"
                class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out"
              />
              <span class="ml-2 text-sm text-gray-600">Remember me</span>
            </label>
            <a href="#" class="text-sm text-indigo-600 hover:text-indigo-800">Forgot password?</a>
          </div>
          <button
            type="submit"
            :disabled="loginLoading"
            class="w-full rounded-md px-4 py-2 font-medium text-white"
            :class="loginLoading ? 'bg-gray-400 cursor-not-allowed' : 'bg-indigo-600 hover:bg-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2'"
          >
            <span v-if="loginLoading">Logging in...</span>
            <span v-else>Login</span>
          </button>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import axios from '../axios'

// State variables
const username = ref('')
const password = ref('')
const rememberMe = ref(false)
const errorMessage = ref('')
const loginLoading = ref(false)
const isLoading = ref(true)

const router = useRouter()

const login = async () => {
  errorMessage.value = ''
  loginLoading.value = true
  try {
    const response = await axios.post(
      `/api/user/login`,
      {
        username: username.value,
        password: password.value,
        rememberMe: rememberMe.value
      },
      {
        headers: {
          'x-api-key': 'Pr0j3cTS3k@1'
        }
      }
    )
    localStorage.setItem('token', response.data.accessToken)
    console.log('Login successful!')
    router.replace('/todo')
  } catch (error) {
    // Handle login error
    if (error.response && error.response.data && error.response.data.message) {
      errorMessage.value = error.response.data.message
    } else {
      errorMessage.value = 'An error occurred during login. Please try again.'
    }
    console.error('Login error:', error)
  } finally {
    loginLoading.value = false
  }
};

// Gives time to load login screen on initial start
onMounted(() => {
  setTimeout(() => {
    isLoading.value = false
  }, 1500) 
});
</script>
