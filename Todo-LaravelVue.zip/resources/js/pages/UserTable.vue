<template>
  <div class="mx-auto w-full max-w-screen-xl px-2">
    <!-- Total Cards -->
    <div class="grid w-full grid-cols-1 gap-4 pb-5 lg:grid-cols-3">
      <div
        class="flex h-auto flex-col items-center justify-between rounded-lg bg-white p-6 shadow-lg"
      >
        <h3 class="text-black-300 mb-2 text-sm font-semibold">Total Users</h3>
        <p class="mb-1 text-2xl font-bold text-cyan-500">{{ totalOverall || 0 }}</p>
      </div>
      <div
        class="flex h-auto flex-col items-center justify-between rounded-lg bg-white p-6 shadow-lg"
      >
        <h3 class="text-black-300 mb-2 text-sm font-semibold">Total Active Users</h3>
        <p class="mb-1 text-2xl font-bold text-green-500">{{ totalActive || 0 }}</p>
      </div>
      <div
        class="flex h-auto flex-col items-center justify-between rounded-lg bg-white p-6 shadow-lg"
      >
        <h3 class="text-black-300 mb-2 text-sm font-semibold">Total Archived Users</h3>
        <p class="mb-1 text-2xl font-bold text-orange-500">{{ totalArchive || 0 }}</p>
      </div>
    </div>
    <div class="overflow-hidden rounded-lg bg-white shadow-lg">
      <!-- Search, Add Button, Filter -->
      <div class="flex flex-col md:flex-row items-start md:items-center justify-between space-y-2 md:space-y-0 md:space-x-4 border-b border-gray-200 p-4">
        <div class="relative w-full md:max-w-md flex-grow">
          <input
            name="search"
            type="text"
            placeholder="Search Username, Name, Email"
            v-model="search"
            @input="debouncedSearch"
            class="w-full rounded-md border border-gray-300 py-2 pl-10 pr-4 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
          />
          <div class="absolute inset-y-0 left-0 flex items-center pl-3">
            <svg
              class="h-5 w-5 text-gray-400"
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 20 20"
              fill="currentColor"
            >
              <path
                fill-rule="evenodd"
                d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z"
                clip-rule="evenodd"
              />
            </svg>
          </div>
        </div>

        <div class="flex flex-wrap md:flex-nowrap items-start md:items-center justify-start md:justify-end space-y-2 md:space-y-0 md:space-x-2 w-full md:w-auto">
          <button
            class="flex items-center w-full md:w-auto rounded-md bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
            @click="addUser()"
          >
            <svg
              class="mr-2 h-5 w-5"
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 20 20"
              fill="currentColor"
            >
              <path
                fill-rule="evenodd"
                d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z"
                clip-rule="evenodd"
              />
            </svg>
            Add User
          </button>
          <div class="relative w-full md:w-auto">
            <select
              name="status"
              v-model="tabStatus"
              @change="changeTabStatus(tabStatus)"
              class="appearance-none w-full md:w-auto rounded-md border border-gray-300 py-2 pl-3 pr-10 focus:outline-none"
            >
              <option value="All">Status</option>
              <option value="Active">Active</option>
              <option value="Archived">Archived</option>
            </select>
            <div
              class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700"
            >
              <svg
                class="h-4 w-4 fill-current"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 20 20"
              >
                <path
                  d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"
                />
              </svg>
            </div>
          </div>
          <div class="relative w-full md:w-auto">
            <select
              name="userType"
              v-model="selectedUserType"
              @change="changeUserType(selectedUserType)"
              class="appearance-none w-full md:w-auto rounded-md border border-gray-300 py-2 pl-3 pr-10 focus:outline-none"
            >
              <option value="All">User Type</option>
              <option value="User">User</option>
              <option value="Admin">Admin</option>
            </select>
            <div
              class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700"
            >
              <svg
                class="h-4 w-4 fill-current"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 20 20"
              >
                <path
                  d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"
                />
              </svg>
            </div>
          </div>
        </div>
      </div>

      <!-- Table -->
      <div class="overflow-x-auto">
        <table class="w-full text-left text-sm text-gray-500">
          <thead class="bg-gray-50 text-xs uppercase text-gray-700">
            <tr>
              <th scope="col" class="px-6 py-3">Username</th>
              <th scope="col" class="px-6 py-3">Name</th>
              <th scope="col" class="px-6 py-3">Email</th>
              <th scope="col" class="px-6 py-3">User Type</th>
              <th scope="col" class="px-6 py-3">Status</th>
              <th scope="col" class="px-6 py-3">Actions</th>
            </tr>
          </thead>
          <tbody v-if="!loadingTable">
            <tr
              v-for="user in userTable"
              :key="user.id"
              class="border-b bg-white hover:bg-gray-50"
            >
              <td class="flex items-center px-6 py-4">
                <img
                  :src="
                    user?.user_detail?.profile_image
                      ? user?.user_detail?.profile_image
                      : '/images/default_pfp.png'
                  "
                  :alt="user.username"
                  class="mr-3 h-10 w-10 rounded-full object-cover"
                />
                <div>
                  <div class="font-medium text-gray-900">{{ user.username }}</div>
                  <div class="text-sm text-gray-500">{{ user.id }}</div>
                </div>
              </td>
              <td class="px-6 py-4">{{ user.user_detail.first_name }} {{ user.user_detail.last_name }}</td>
              <td class="px-6 py-4">{{ user.user_detail.email }}</td>
              <td class="px-6 py-4">{{ user.user_type }}</td>
              <td class="px-6 py-4">
                <span
                  :class="[
                    'rounded-full px-2 py-1 text-xs font-semibold',
                    user.deleted_at !== null
                      ? 'bg-red-100 text-red-800'
                      : 'bg-green-100 text-green-800'
                  ]"
                >
                  {{ user.deleted_at !== null ? 'Archived' : 'Active' }}
                </span>
              </td>
              <td class="px-6 py-4">
                <div v-if="user.deleted_at">
                  <button
                    @click="restoreUser('Restore', user.id)"
                    class="mr-2 text-green-600 hover:text-green-900"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      class="h-5 w-5"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      stroke-width="2"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    >
                      <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
                      <path d="M3 3v5h5" />
                      <path d="M12 7v5l4 2" />
                    </svg>
                  </button>
                  <button
                    @click="deleteUser('Delete', user.id)"
                    class="text-red-600 hover:text-red-900"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      class="h-5 w-5"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path
                        fill-rule="evenodd"
                        d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z"
                        clip-rule="evenodd"
                      />
                    </svg>
                  </button>
                </div>
                <div v-else>
                  <button
                    @click="updateUser(user)"
                    class="mr-2 text-blue-600 hover:text-blue-900"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      class="h-5 w-5"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path
                        d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z"
                      />
                    </svg>
                  </button>
                  <button
                    @click="archiveUser('Archive', user.id)"
                    class="text-orange-600 hover:text-orange-900"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      class="h-5 w-5"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path d="M4 3a2 2 0 100 4h12a2 2 0 100-4H4z" />
                      <path
                        fill-rule="evenodd"
                        d="M3 8h14v7a2 2 0 01-2 2H5a2 2 0 01-2-2V8zm5 3a1 1 0 011-1h2a1 1 0 110 2H9a1 1 0 01-1-1z"
                        clip-rule="evenodd"
                      />
                    </svg>
                  </button>
                </div>
              </td>
            </tr>
          </tbody> 
        </table>
      </div>
      
      <!-- Loading Overlay -->
      <LoadingTable v-if="loadingTable" message="Loading data..." />

      <!-- Pagination -->
      <Pagination
        :currentPage="page + 1"
        :pageSize="limit"
        :totalItems="totalOverall"
        @changePage="handlePageChange"
        @changeLimit="handleLimitChange"
      />
    </div>
    <ConfirmationModal
      :isOpen="isActionModalOpen"
      :action="modalAction"
      :id="selectedUserID"
      :type="modalType"
      :loading="loadingModal"
      @close="closeActionModal"
      @confirm="handleActionConfirm"
    />
    <UserModal
      :isOpen="isUserModalOpen"
      :userData="userData"
      :type="modalType"
      :loading="loadingModal"
      :isEditMode="isEditMode"
      @close="closeUserModal"
      @confirm="handleConfirm"
    />
  </div>
</template>

<script setup>
import axios from '../axios'
import { ref, reactive, onMounted, watch } from 'vue'
import { useToast } from 'vue-toastification'
import LoadingTable from '../components/Tables/LoadingTable.vue'
import Pagination from '../components/Tables/Pagination.vue';
import ConfirmationModal from '../components/ConfirmationModal.vue'
import UserModal from '../components/Modals/UserModal.vue'

const toast = useToast()

const userTable = ref([])
const search = ref('')
const tabStatus = ref('All')
const selectedUserType = ref('All')
const page = ref(0)
const limit = ref(5)
const totalOverall = ref(0)
const totalActive = ref(0)
const totalArchive = ref(0)
const loadingTable = ref(false)
const timeout = ref(null)

const isActionModalOpen = ref(false)
const modalAction = ref('')
const selectedUserID = ref('')

const isUserModalOpen = ref(false)
const userData = reactive({
  username: '',
  first_name: '',
  last_name: '',
  email: '',
  password: '',
  user_type: '',
})
const isEditMode = ref(false) 

const modalType = ref('') // Signify Add/Update <Module>
const loadingModal = ref(false)

const fetchTable = async () => {
  loadingTable.value = true
  try {
    const response = await axios.post(
      '/api/user/list',
      {
        page: page.value,
        limit: limit.value,
        search: search.value,
        tabStatus: tabStatus.value,
        selectedUserType: selectedUserType.value
      },
      {
        headers: {
          'x-api-key': 'Pr0j3cTS3k@1'
        }
      }
    )

    const {
      data: {
        data: users,
        totalOverall: overall,
        totalActive: active,
        totalArchive: archive
      }
    } = response

    userTable.value = users
    totalOverall.value = overall
    totalActive.value = active
    totalArchive.value = archive
  } catch (error) {
    toast.error('Error fetching data!', {
      position: 'top-center'
    })
    console.error('Error fetching data!', error)
  } finally {
    loadingTable.value = false
  }
}

const changeTabStatus = (status) => {
  tabStatus.value = status
  page.value = 0
  fetchTable()
}

const handlePageChange = (newPage) => {
  page.value = newPage - 1
  fetchTable()
}

const handleLimitChange = (newLimit) => {
  limit.value = Number(newLimit)
  page.value = 0
  fetchTable()
}

const changeUserType = (status) => {
  selectedUserType.value = status
  page.value = 0
  fetchTable()
}

const debouncedSearch = () => {
  if (timeout.value) {
    clearTimeout(timeout.value)
  }
  timeout.value = setTimeout(() => {
    fetchTable()
  }, 500)
}

watch(search, () => {
  debouncedSearch()
  page.value = 0
})

const addUser = () => {
  Object.assign(userData, {
    username: '',
    first_name: '',
    last_name: '',
    email: '',
    password: '',
    user_type: '',
  });
  modalType.value = 'Add User'
  isEditMode.value = false
  isUserModalOpen.value = true
}

const updateUser = (user) => {
  Object.assign(userData, {
    username: user.username,
    first_name: user.user_detail.first_name,
    last_name: user.user_detail.last_name,
    email: user.user_detail.email,
    password: '',
    user_type: user.user_type,
  });
  selectedUserID.value = user.id
  modalType.value = 'Update User'
  isEditMode.value = true
  isUserModalOpen.value = true
}

const archiveUser = (action, id) => {
  modalAction.value = action
  modalType.value = 'User ID'
  selectedUserID.value = id
  isActionModalOpen.value = true
}

const restoreUser = (action, id) => {
  modalAction.value = action
  modalType.value = 'User ID'
  selectedUserID.value = id
  isActionModalOpen.value = true
}

const deleteUser = (action, id) => {
  modalAction.value = action
  modalType.value = 'User ID'
  selectedUserID.value = id
  isActionModalOpen.value = true
}

const closeUserModal = () => {
  isUserModalOpen.value = false
}

const closeActionModal = () => {
  isActionModalOpen.value = false
}

const handleConfirm = async () => {
  loadingModal.value = true
  const url = isEditMode.value ? `/api/user/update/${selectedUserID.value}` : '/api/user/add'
  try {
    const response = await axios.post(url, userData, {
      headers: {
        'x-api-key': 'Pr0j3cTS3k@1'
      }
    })

    const { data } = response

    if (data.status !== 'error') {
      toast.success(data.message, { position: 'top-center' })
      fetchTable()
      closeUserModal()
    } else {
      toast.error(data.message, {
        position: 'top-center'
      })
    }
  } catch (error) {
    console.error('Failed to submit User: ', error)
    toast.error(error?.response?.data?.message || 'Something went wrong, please try again!', {
      position: 'top-center'
    })
  } finally {
    loadingModal.value = false
  }
}

const handleActionConfirm = async () => {
  loadingModal.value = true
  try {
    let endpoint = ''
    let method = ''
    let config = {
      headers: {
        'x-api-key': 'Pr0j3cTS3k@1'
      }
    }

    if (modalAction.value === 'Archive') {
      method = axios.put
      endpoint = `/api/user/archive/${selectedUserID.value}`
    } else if (modalAction.value === 'Restore') {
      method = axios.put
      endpoint = `/api/user/restore/${selectedUserID.value}`
    } else if (modalAction.value === 'Delete') {
      method = axios.delete
      endpoint = `/api/user/delete/${selectedUserID.value}`
    }

    let response
    if (modalAction.value === 'Delete') {
      response = await method(endpoint, config)
    } else {
      response = await method(endpoint, null, config)
    }

    const { data } = response

    if (data.status !== 'error') {
      toast.success(data.message, { position: 'top-center' })
      fetchTable()
    } else {
      toast.error(data.message, {
        position: 'top-center'
      })
    }
  } catch (error) {
    toast.error(error?.response?.data?.message || 'Error updating user, please try again!', {
      position: 'top-center'
    })
    console.error(`Error updating user: `, error)
  } finally {
    loadingModal.value = false
    closeActionModal()
  }
}

onMounted(() => {
  fetchTable()
});
</script>
