<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class UserDetailSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $user_detail_data = [
            [
                'id' => 1,
                'user_id' => 1,
                'first_name' => 'Da',
                'last_name' => 'Wei',
                'email' => 'dawei@gmail.com',
                'password' => bcrypt('123'),
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'id' => 2,
                'user_id' => 2,
                'first_name' => 'Zeke',
                'last_name' => 'Beke',
                'email' => 'zekebeke@gmail.com',
                'password' => bcrypt('123'),
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'id' => 3,
                'user_id' => 3,
                'first_name' => 'John',
                'last_name' => 'Doe',
                'email' => 'johndoe@gmail.com',
                'password' => bcrypt('123'),
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'id' => 4,
                'user_id' => 4,
                'first_name' => 'Jane',
                'last_name' => 'Doe',
                'email' => 'janedoe@gmail.com',
                'password' => bcrypt('123'),
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'id' => 5,
                'user_id' => 5,
                'first_name' => 'Lorem',
                'last_name' => 'Ipsum',
                'email' => 'loremipsum@gmail.com',
                'password' => bcrypt('123'),
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ];

        foreach ($user_detail_data as $data){
            \App\Models\UserDetail::factory()->create($data);
        }
    }
}
