<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $user_data = [
            [
                'id' => 1,
                'username' => 'dawei',
                'password' => bcrypt('123'),
                'user_type' => 'Admin',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'id' => 2,
                'username' => 'zekebeke',
                'password' => bcrypt('123'),
                'user_type' => 'User',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'id' => 3,
                'username' => 'johndoe',
                'password' => bcrypt('123'),
                'user_type' => 'Admin',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'id' => 4,
                'username' => 'janedoe',
                'password' => bcrypt('123'),
                'user_type' => 'User',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'id' => 5,
                'username' => 'loremipsum',
                'password' => bcrypt('123'),
                'user_type' => 'User',
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ];

        foreach ($user_data as $data){
            \App\Models\User::factory()->create($data);
        }
    }
}
