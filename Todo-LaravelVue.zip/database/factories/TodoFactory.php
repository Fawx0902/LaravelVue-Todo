<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Todo;

class TodoFactory extends Factory
{
    public function definition()
    {
    
        return [
            'user_id' => $this->faker->numberBetween(1, 5),
            'todo' => $this->faker->word,
            'status' => $this->faker->randomElement(['Pending', 'Completed']),
            'description' => $this->faker->paragraph,
            'created_at' => now(),
            'updated_at' => now(),
        ];
    }
}